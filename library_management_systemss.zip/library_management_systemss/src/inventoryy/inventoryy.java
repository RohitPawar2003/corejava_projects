package inventoryy;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicInteger;

enum inv{
	SNEAKERS, BOOTS, SANDALS, FORMAL
}

class ValidationException extends Exception{
	public ValidationException(String msg) {
		super(msg);
	}
}

class inventor{
	private static final AtomicInteger idGenerator=new AtomicInteger(88);
	private int id;
	private String brand;
	private String model;
	public double price;
	private boolean instocks;
	private inv type;
	
	public inventor(String brand, String model, double price, boolean instocks, inv type ) throws ValidationException{
		this.id=idGenerator.getAndIncrement();
		this.brand=brand;
		this.model=model;
		this.price=price;
		this.instocks=instocks;
		this.type=type;
	}
	
	public void setName(String brand)throws ValidationException{
		if(brand.length()<3 || brand.length()>10) {
			throw new ValidationException("invalids");
		}
		this.brand=brand;
	}
	
	public void setName1(String model)throws ValidationException{
		if(model.length()<3 || model.length()>10) {
			throw new ValidationException("invalids");
		}
		this.model=model;
	}
	
	private inv ValidateEnum(String input) throws ValidationException{
		try {
		return inv.valueOf(input.toString());
		}
		catch(Exception e) {
			throw new ValidationException("invalids");
		}
	}
	
	public void setName8() {
		return;
	}
	
	public int getid() {
		return id;
	}
	
	public String getbrand() {
		return brand;
	}
	
	public String getmodel() {
		return model;
	}
	
	public double getprice() {
		return price;
	}
	
	public boolean getinstocks() {
		return instocks;
	}
	
	public inv gettype() {
		return type;
	}

	@Override
	public String toString() {
		return "inventor [id=" + id + ", brand=" + brand + ", model=" + model + ", price=" + price + ", instocks="
				+ instocks + ", type=" + type + "]";
	}
	
}

public class inventoryy {
	private static List<inventor> in=new ArrayList<>();
	private static Scanner sc=new Scanner(System.in);
	
	public static void main(String[]args) {
		try {
			in.add(new inventor("adidas","adidas",8888.8,true,inv.SNEAKERS));
			in.add(new inventor("adidas","adidas",8888.8,true,inv.SNEAKERS));
			in.add(new inventor("adidas","adidas",8888.8,true,inv.SNEAKERS));
			in.add(new inventor("adidas","adidas",8888.8,true,inv.SNEAKERS));
		}
		catch(ValidationException e) {
			System.out.println("exceptions"+e.getMessage());
		}
		
		int choice;
		do {
			System.out.println("add shoe:");
			System.out.println("display shoe:");
			System.out.println("shoe sorted By Price:");
			System.out.println("display costliest shoe:");
			System.out.println("exit");
			
			choice=sc.nextInt();
			
			switch(choice) {
			case 1->addShoe();
			case 2->displayShoe();
			case 3->sortedPrice();
			case 4->costliestShoe();
			default->System.out.println("invalid choice");
			}
		}while(choice!=8);
	    }
	    public static void addShoe() {
		try {
			System.out.println("enter brand:");
			String brand=sc.next();
			System.out.println("enter model:");
			String model=sc.next();
			System.out.println("enter price:");
			double price=sc.nextDouble();
			System.out.println("availabilitys:");
			boolean avai=sc.nextBoolean();
			System.out.println("enter type:");
			inv type=inv.valueOf(sc.next());
			
			in.add(new inventor(brand,model,price,avai,type));
		}
		catch(ValidationException e) {
			System.out.println("exceptions"+e.getMessage());
		}
	}
	    static void displayShoe() {
			for(inventor x: in) {
				System.out.println(x);
			}
		}
	    
	    static void sortedPrice() {
	    	in.sort(Comparator.comparingDouble(x->x.price));
	    	displayShoe();
	    }
	    
	    static void costliestShoe() {
	    	inventor max=Collections.max(in, Comparator.comparingDouble(x->x.price));
	    	System.out.println("costliest");
	    }
}
