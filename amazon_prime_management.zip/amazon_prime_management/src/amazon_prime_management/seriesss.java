package amazon_prime_management;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicInteger;

enum webseriess{
	GAMEOFTHRONES, VAMPIREDIARIES, THEORIGINALS, ONEPIECE 
}

class ValidationException extends Exception{
	public ValidationException(String msg) {
		super(msg);
	}
}

class web{
	private static AtomicInteger idGenerator=new AtomicInteger(80);
	public int id;
	public String name;
	private String brand;
	public double rate;
	public int rating;
	private int range;
	public boolean avai;
	private webseriess type;
	
	public web(String name, String brand, double rate, int rating, int range, boolean avai, webseriess type)throws ValidationException{
		this.id=idGenerator.getAndIncrement();
		this.name=name;
		this.brand=brand;
		this.rate=rate;
		this.rating=rating;
		this.range=range;
		this.avai=avai;
		this.type=type;
	}
	
	public void getName()throws ValidationException{
		if(name.length()<3||name.length()>10) {
			throw new ValidationException("invalids");
		}
		this.name=name;
	}
	
	public void getName1()throws ValidationException{
		if(brand.length()<3||brand.length()>10) {
			throw new ValidationException("invalids");
		}
		this.brand=brand;
	}
	
	public void getRate()throws ValidationException{
		if(rate<0||rate==0) {
			throw new ValidationException("invalids");
		}
		this.rate=rate;
	}
	
	public webseriess validateenum(String input)throws ValidationException{
		try{
			return webseriess.valueOf(input.toUpperCase());
		}
	catch(IllegalArgumentException e ) {
		throw new ValidationException("invalidss"+ Arrays.toString(webseriess.values()));
	}
	}	
	
	public static AtomicInteger getIdGenerator() {
		return idGenerator;
	}

	public static void setIdGenerator(AtomicInteger idGenerator) {
		web.idGenerator = idGenerator;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public int getRange() {
		return range;
	}

	public void setRange(int range) {
		this.range = range;
	}

	public boolean isAvai() {
		return avai;
	}

	public void setAvai(boolean avai) {
		this.avai = avai;
	}

	public webseriess getType() {
		return type;
	}

	public void setType(webseriess type) {
		this.type = type;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	@Override
	public String toString() {
		return "web [id=" + id + ", name=" + name + ", brand=" + brand + ", rate=" + rate + ", rating=" + rating
				+ ", range=" + range + ", avai=" + avai + ", type=" + type + "]";
	}
	
}

public class seriesss {
	private static List<web> series=new ArrayList<>();
	private static Scanner sc=new Scanner(System.in);
	
    public static void main(String[]args) {
    	try {
    		series.add(new web("seriesss1","brand1",1000,8,8,true,webseriess.ONEPIECE));
    		series.add(new web("seriesss1","brand1",1000,8,8,true,webseriess.ONEPIECE));
    		series.add(new web("seriesss1","brand1",1000,8,8,true,webseriess.ONEPIECE));
    		series.add(new web("seriesss2","brand1",1000,8,8,true,webseriess.ONEPIECE));
    	}
    	catch(ValidationException e) {
    		System.out.println("exceptions"+e.getMessage());
    	}
    	
    	int choice;
    	do {
    		System.out.println("1:add webseriess:");
    		System.out.println("2:display webseriesss:");
    		System.out.println("3:sort rate:");
    		System.out.println("4:sort id:");
    		System.out.println("5:sort rating:");
    		System.out.println("6:order webseriess:");
    		System.out.println("7:costliest webseries:");
    		System.out.println("8:removeif:");
    		System.out.println("9:update rate:");
    		System.out.println("10:search id:");
    		System.out.println("11:exit");
    		
    		choice=sc.nextInt();
    		switch(choice) {
    		case 1->addWebseriess();
    		case 2->displayWebseriesss();
    		case 3->sortRate();
    		case 4->sortId();
    		case 5->sortRating();
    		case 6->orderWebseriess();
    		case 7->costliestWebseries();
    		case 8->removeif();
    		case 9->updateRate();
    		case 10->{
    			web result=searchId();
    			if(result!=null) {
    				System.out.println("searched"+result);
    			}
    			else {
    				System.out.println("searched________");
    			}
    		}
    		case 11->System.out.println("exit");
    		default->System.out.println("invalids");
    		}
    	}while(choice!=11);
    }
    
    public static void addWebseriess(){
    	try {
    	System.out.println("enter name:");
    	String name=sc.next();
    	System.out.println("enter brand:");
    	String brand=sc.next();
    	System.out.println("enter rate:");
    	double rate=sc.nextDouble();
    	System.out.println("enter rating:");
    	int rating=sc.nextInt();
    	System.out.println("enter range:");
    	int range=sc.nextInt();
    	System.out.println("enter availabilitys:");
    	boolean avai=sc.nextBoolean();
    	System.out.println("enter type:");
    	webseriess type=webseriess.valueOf(sc.next().toUpperCase());
    	
    	series.add(new web(name,brand,rate,rating,range,avai,type));
    	}
    	catch(ValidationException e) {
    		System.out.println("inavalids"+e.getMessage());
    	}
    }
    
    static void displayWebseriesss() {
    	for(web x: series) {
    		System.out.println(x);
    	}
    }
    
    static void sortRate() {
    	series.sort(Comparator.comparingDouble(x->x.rate));
    	displayWebseriesss();
    }
    
    static void sortId() {
    	series.sort(Comparator.comparingInt(x->x.id));
    	displayWebseriesss();
    }
    
    static void sortRating() {
    	series.sort(Comparator.comparingInt(x->x.rating));
    	displayWebseriesss();
    }
    
    static void orderWebseriess() {
    	series.sort(Comparator.comparingDouble((web x)->x.rate).reversed());
    	displayWebseriesss();
    }
    
    static void costliestWebseries() {
    	web max=Collections.max(series, Comparator.comparingDouble(x->x.rate));
    	System.out.println("costliestWebseries"+max);
    }
    
    static void removeif() {
    	series.removeIf(x->!x.avai);
    	displayWebseriesss();
    }
    
    static void updateRate() {
    	System.out.println("enter name");
    	String s=sc.next();
    	System.out.println("enter rate");
    	double r=sc.nextDouble();
    	
    	boolean searched=false;
    	for(web x: series) {
    		if(x.name.equalsIgnoreCase(s)) {
    			x.rate=r;
    			searched=true;
    		}
    	}
    		if(searched) {
    		System.out.println("update rate"+s);
    		}
    		else {
    			System.out.println("rate____"+s);
    		}
    	
    }
    
    static web searchId() {
    	System.out.println("enter id");
    	int id=sc.nextInt();
    	
    	for(web x: series) {
    		if(x.id==id)
    			return x;
    		}
    		return null;
    }
    
}
