package hotelllllll_ms;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicInteger;

enum roomtype{
	SINGLE, DOUBLE, STANDARD, DELUXE
}

class ValidationException extends Exception{
	public ValidationException(String msg) {
		super(msg);
	}
}

class room{
	private static AtomicInteger idGenerator=new AtomicInteger(80);
	public int id;
	public String name;
	private String floor;
	public double rate;
	public int rating;
	public boolean avai;
	private roomtype type;
	
	public room(String name, String floor, double rate, int rating, boolean avai, roomtype type)throws ValidationException{
		this.id=idGenerator.getAndIncrement();
		this.name=name;
		this.floor=floor;
		this.rate=rate;
		this.rating=rating;
		this.avai=avai;
		this.type=type;
	}
	
	public void setName(String name)throws ValidationException{
		if(name.length()<3 || name.length()>10) {
			throw new ValidationException("invalids");
		}
		this.name=name;
	}
	
	public void setName1(String floor)throws ValidationException{
		if(floor.length()<3 || floor.length()>10) {
			throw new ValidationException("invalids");
		}
		this.floor=floor;
	}
	
	public void setRating(int rating)throws ValidationException{
		if(rating<3 || rating>10) {
			throw new ValidationException("invalids");
		}
	}
	
	public int getid() {
		return id;
	}
	
	public String getname() {
		return name;
	}
	
	public String getfloor() {
		return floor;
	}
	
	public double getrate() {
		return rate;
	}
	
	public int getrating() {
		return rating;
	}
	
	public roomtype gettype() {
		return type;
	}

	@Override
	public String toString() {
		return "room [id=" + id + ", name=" + name + ", floor=" + floor + ", rate=" + rate + ", rating=" + rating
				+ ", avai=" + avai + ", type=" + type + "]";
	}
	
	
}

public class hotellll {
	private static List<room> rooms=new ArrayList<>();
	private static Scanner sc=new Scanner(System.in);
	
	public static void main(String[]args) {
		try {
			rooms.add(new room("roomx","eight",1000,8,true, roomtype.DELUXE));
			rooms.add(new room("roomy","eight",1000,8,true, roomtype.DELUXE));
			rooms.add(new room("roomz","eight",1000,8,true, roomtype.DELUXE));
			rooms.add(new room("roomi","eight",1000,8,true, roomtype.DELUXE));
		}
		catch(ValidationException e) {
			System.out.println("exceptions"+e.getMessage());
		}
		
		int choice;
		do {
			System.out.println("1:add room:");
			System.out.println("2:display room:");
			System.out.println("3:sort rate:");
			System.out.println("4:sort id:");
			System.out.println("5:costliest room:");
			System.out.println("6:rate:");
			System.out.println("7:order room:");
			System.out.println("exit");
			System.out.println("8:sort rating:");
			
			choice=sc.nextInt();
			switch(choice) {
			case 1->addRoom();
			case 2->displayRoom();
			case 3->sortRate();
			case 4->sortId();
			case 5->costliestRoom();
			case 6->updaterate();
			case 7->orderRoom();
			case 8->System.out.println("exit");
			case 9->sortRating();
			case 10->removeif();
			default->System.out.println("invalid choice");
			}
		}while(choice!=8);
	}
	
	public static void addRoom() {
		try {
			System.out.println("enter name:");
			String name=sc.next();
			System.out.println("enter floor:");
			String floor=sc.next();
			System.out.println("enter rate:");
			double rate=sc.nextDouble();
			System.out.println("enter rating:");
			int rating=sc.nextInt();
			System.out.println("enter availabilitys:");
			boolean avai=sc.nextBoolean();
			System.out.println("enter type:");
			roomtype type=roomtype.valueOf(sc.next());
			
			rooms.add(new room(name,floor,rate,rating,avai,type));
		}
		catch(ValidationException e) {
			System.out.println("exceptions"+e.getMessage());
		}
	}
	
	static void displayRoom() {
		for(room x: rooms) {
			System.out.println(x);
		}
	}
	
	static void sortRate() {
		rooms.sort(Comparator.comparingDouble(x->x.rate));
		displayRoom();
	}
	
	static void sortId() {
		rooms.sort(Comparator.comparingInt(x->x.id));
		displayRoom();
	}
	
	static void sortRating() {
		rooms.sort(Comparator.comparingInt(x->x.rating));
		displayRoom();
	}
	
	static void costliestRoom() {
		room max=Collections.max(rooms, Comparator.comparingDouble(x->x.rate));
        System.out.println("costliestroom"+max);		
	}
	
	static void updaterate() {
		System.out.println("enter name");
		String r=sc.next();
		System.out.println("enter rate");
		double ra=sc.nextDouble();

		for(room x: rooms) {
				if(x.name.equalsIgnoreCase(r)) {
					x.rate=ra;
				}
				System.out.println("updated rate"+r);
			}
		}
	
	static void removeif() {
		rooms.removeIf(x->!x.avai);
		displayRoom();
	}
	
	static void orderRoom() {
		rooms.sort(Comparator.comparingDouble((room x)->x.rate).reversed());
		displayRoom();
	}
	

}
