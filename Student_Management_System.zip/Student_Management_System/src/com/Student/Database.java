package com.Student;

import com.Student.Student;

import com.Student.Course;

import com.Student.CourseSS;

import java.util.ArrayList;

import java.util.List;

public class Database {

	private static List<Student> students=new ArrayList<>();
	private static List<Course> courses=new ArrayList<>();
	
	static {
		courses.add(Course.CORE_JAVA);
		courses.add(Course.DBT);
		courses.add(Course.PYTHON);
		courses.add(Course.MERN);
		courses.add(Course.WEB_JAVA);
		courses.add(Course.DEV_OPS);
		courses.add(Course.DATABASE);
	}
	
	public static List<Student> getStudents(){
		return students;
	}
	
	public static void addStudents(Student student) {
		students.add(student);
	}
	
	public static void removeStudents(Student student) {
		students.remove(student);
	}
	
	public static List<Course> getCourses(){
		return courses;
	}
	
	public static Course getCourseByName(String courseName) {
	    if (courseName == null) return null;
	    courseName = courseName.trim();

	    for (Course c : courses) {
	        if (c != null && c.getcoursename() != null && c.getcoursename().equalsIgnoreCase(courseName)) {
	            return c;
	        }
	    }
	    return null;
	}

	
}
