package com.Student;

import com.Student.*;

public class CourseSS {

	private String coursename;
	private int minmarks;
	private int availableseats;

	public CourseSS(String coursename, int minmarks, int availablemarks) {
		this.coursename=coursename;
		this.minmarks=minmarks;
		this.availableseats=availableseats;
	}
	
	public String getcoursename() {
		return coursename;
	}
	
	public int getminmarks() {
		return minmarks;
	}
	
	public int getavailableseats() {
		return availableseats;
	}
	
	public void availableseats(int availableseats) {
		this.availableseats=availableseats;
	}
	
	public int setavailableseats() {
		return availableseats;
	}
	
	@Override
	public String toString() {
		return "Course{"
				+ "coursename" +coursename+ "minmarks" +minmarks+ "availableseats" +availableseats+ "}";
	}
	
}
