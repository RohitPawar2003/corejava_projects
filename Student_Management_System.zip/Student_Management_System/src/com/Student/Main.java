package com.Student;

import java.util.Scanner;

public class Main {

	public static void main(String[]args) {
	Scanner sc=new Scanner(System.in);
	
	boolean running=true;
	
	while(running) {
		System.out.println("1. add student");
		System.out.println("2. list all students");
		System.out.println("3. cancel admission");
		System.out.println("4. search student by email");
		System.out.println("5. list student by course");
		System.out.println("0.exit");
		
		System.out.println("enter choice");
		
		int choice=sc.nextInt();
		
		sc.nextLine();
		
		switch(choice) {
		
		case 1:
            System.out.print("Enter Name: ");
            String name = sc.nextLine();
            System.out.print("Enter Email: ");
            String email = sc.nextLine();
            System.out.print("Enter Marks: ");
            int marks = sc.nextInt();
            sc.nextLine();
            System.out.print("Enter Course Name: ");
            String course = sc.nextLine();
            System.out.println(Validation.admitStudent(name, email, marks, course));
            break;

        case 2:
        	System.out.println(Validation.listAllStudents());
            break;

        case 3:
            System.out.print("Enter Email to cancel admission: ");
            String cancelEmail = sc.nextLine();
            System.out.println(Validation.cancelAdmission(cancelEmail));
            break;

        case 4:
        	System.out.print("Enter Email to search: ");
            String searchEmail = sc.nextLine();
            System.out.println(Validation.searchStudentByEmail(searchEmail));
            break;

        case 5:
            System.out.print("Enter Course Name: ");
            String courseName = sc.nextLine();
            System.out.println(Validation.listStudentsByCourse(courseName));
            break;

        case 0:
            running = false;
            System.out.println("exit");
            break;

        default:
            System.out.println("invalid choice");
    }
}
	
	sc.close();
		
		}
		
		
	
	}

