package com.Student;

import java.time.LocalDate;

import java.util.Objects;

public class Student {

	private int id;
	private String name;
	private String email;
	private int marks;
	private LocalDate admissionDate;
	private Course course;
	
	public Student(String name, String email, int marks, LocalDate admissionDate, Course course ) {
		this.name=name;
		this.email=email;
		this.marks=marks;
	    this.admissionDate=admissionDate;
	    this.course=course;
	}
	
	public Student(String name2, String email2, int marks2, String getcoursename) {
		
	}

	public String getname() {
		return name;
	}
	
	public String getemail() {
		return email;
	}
	
	public int getmarks() {
		return marks;
	}
	
	public LocalDate getadmissionDate() {
		return admissionDate;
	}
	
	public Course course() {
		return course;
	}
	
	@Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Student)) return false;
        Student student = (Student) o;
        return Objects.equals(email, student.email);
    }
	
	public int hashcode() {
		return Objects.hash(email);
	}
	
	@Override
	public String toString() {
		return "Student{ "
				+ "name" +name+ "email" +email+ "marks" +marks+ "admissionDate" +admissionDate+ "course" +course+ " \"}";
						
	}

	public String getcoursename() {
		return null;
	}
	
	
}
