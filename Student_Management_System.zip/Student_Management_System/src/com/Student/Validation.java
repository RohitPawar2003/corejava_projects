package com.Student;

public class Validation {

	public static String admitStudent(String name, String email, int marks, String coursename) {
        
        for (Student s : Database.getStudents()) {
            if (s.getemail().equalsIgnoreCase(email)) {
                return "Admission failed: Email already exists!";
            }
        }

        Course course = Database.getCourseByName(coursename);
        if (course == null) {
            return "Admission failed: Course not found!";
        }

        if (marks < course.getminmarks()) {
            return "Admission failed: Marks below minimum requirement (" + course.getminmarks() + ")";
        }

        if (course.getavailableseats() <= 0) {
            return "Admission failed: No seats available in " + course.getcoursename();
        }

        Student student = new Student(name, email, marks, course.getcoursename());
        Database.addStudents(student);
        course.setavailableseats(course.getavailableseats() - 1);

        return "Admission successful for " + name + " in course " + course.getcoursename();
    }

    public static String cancelAdmission(String email) {
        Student target = null;
        for (Student s : Database.getStudents()) {
            if (s.getemail().equalsIgnoreCase(email)) {
                target = s;
                break;
            }
        }

        if (target == null) {
            return "Cancellation failed: Student with email " + email + " not found.";
        }

        Course course = Database.getCourseByName(target.getcoursename());
        if (course != null) {
            course.setavailableseats(course.getavailableseats() + 1);
        }
        Database.removeStudents(target);

        return "Admission cancelled for " + target.getname();
    }

    public static String searchStudentByEmail(String email) {
        for (Student s : Database.getStudents()) {
            if (s.getemail().equalsIgnoreCase(email)) {
                return "Student found: " + s.toString();
            }
        }
        return " Student with email " + email + " not found.";
    }

    public static String listAllStudents() {
        if (Database.getStudents().isEmpty()) {
            return "No students admitted yet.";
        }
        StringBuilder sb = new StringBuilder("📋 All Students:\n");
        for (Student s : Database.getStudents()) {
            sb.append(s).append("\n");
        }
        return sb.toString();
    }

    public static String listStudentsByCourse(String courseName) {
        boolean found = false;
        StringBuilder sb = new StringBuilder("📋 Students in " + courseName + ":\n");
        for (Student s : Database.getStudents()) {
            if (s.getcoursename().equalsIgnoreCase(courseName)) {
                sb.append(s).append("\n");
                found = true;
            }
        }
        if (!found) return "No students found in course " + courseName;
        return sb.toString();
    }	

    
}
