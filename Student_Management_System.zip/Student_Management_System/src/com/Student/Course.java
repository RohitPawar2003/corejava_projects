package com.Student;

public enum Course {
	
	CORE_JAVA(80, 8),
    DBT(80, 8),
    PYTHON(80, 8),
    MERN(80, 8),
    WEB_JAVA(80, 8),
    DEV_OPS(80, 8),
    DATABASE(80, 8);

    private int minmarks;
    private int availableseats;

    Course(int minMarks, int availableseats) {
        this.minmarks = minMarks;
        this.availableseats = availableseats;
    }

    public int getminmarks() { return minmarks; }
    public int getavailableseats() { return availableseats; }
    public void setavailableseats(int availableseats) {
        this.availableseats = availableseats;
    }

	String getcoursename() {
		return null;
	}

}
