package mobile_store_management;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.atomic.AtomicInteger;

import java.util.List;
import java.util.Scanner;

enum brands{
	APPLE1, APPLE2, APPLE3, APPLE4
}

class ValidationException extends Exception{
	public ValidationException(String msg) {
		super(msg);
	}
}

class mob{
	private static AtomicInteger idGenerator=new AtomicInteger(80);
	public int id;
	public String name;
	private String brand;
	public double price;
	public int rating;
	private int range;
	public boolean avai;
	private brands type;
	
	public mob(String name, String brand, double price, int rating, int range, boolean avai, brands type)throws ValidationException {
		this.id=idGenerator.getAndIncrement();
		this.id=id;
		this.name=name;
		this.brand=brand;
		this.price=price;
		this.rating=rating;
		this.range=range;
		this.avai = avai;
		this.type = type;
	}
	
	public void getName(String name)throws ValidationException{
		if(name.length()<3||name.length()>10) {
			throw new ValidationException("invalids");
		}
		this.name=name;
	}
	
	public void getbrand(String brand)throws ValidationException{
		if(brand.length()<3||brand.length()>10) {
			throw new ValidationException("invalids");
		}
		this.brand=brand;
	}
	
	public void getprice(double price)throws ValidationException{
		if(price==0||price<0) {
			throw new ValidationException("invalids");
		}
		this.price=price;
	}
	
//	public class enumvalidate{
//		public static brands validatebrand(String input)throws ValidationException{
//			try {
//				return brands.valueOf(input.toUpperCase());
//			}
//			catch(ValidationException e) {
//				throw new ValidationException(input.brands);
//			}
//		}
//	}
	
	public static AtomicInteger getIdGenerator() {
		return idGenerator;
	}

	public static void setIdGenerator(AtomicInteger idGenerator) {
		mob.idGenerator = idGenerator;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}
	
	public void getRange(int range) {
		this.range=range;
	}

	public boolean isAvai() {
		return avai;
	}

	public void setAvai(boolean avai) {
		this.avai = avai;
	}

	public brands getType() {
		return type;
	}

	public void setType(brands type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "mob [id=" + id + ", name=" + name + ", brand=" + brand + ", price=" + price + ", rating=" + rating
				+ ", avai=" + avai + ", type=" + type + "]";
	}
	
}

public class mobilesm {
	private static List<mob> mobiless=new ArrayList<>();
	private static Scanner sc=new Scanner(System.in);
	
	public static void main(String[]args) {
		try {
			mobiless.add(new mob("x","y",80,8,8,true,brands.APPLE4));
			mobiless.add(new mob("x","y",80,8,8,true,brands.APPLE4));
			mobiless.add(new mob("x","y",80,8,8,true,brands.APPLE4));
			mobiless.add(new mob("x","y",80,8,8,true,brands.APPLE4));
		}
		catch(ValidationException e) {
			System.out.println("exceptions"+e.getMessage());
		}
		
		int choice;
		do {
			System.out.println("1:add mob:");
			System.out.println("2:display mob:");
			System.out.println("3:sort price:");
			System.out.println("4:sort id:");
			System.out.println("5:costliest mob:");
			System.out.println("6:order mob:");
			System.out.println("7:update price:");
			System.out.println("8:removeif:");
			System.out.println("9:sort rating:");
			System.out.println("10:searchbyid:");
			System.out.println("exit");
			
			choice=sc.nextInt();
			switch(choice) {
			case 1->addMobi();
			case 2->displayMobi();
			case 3->sortPrice();
			case 4->sortId();
			case 5->costliestMobi();
			case 6->orderMob();
			case 7->updatePrice();
			case 8->removeif();
			case 9->sortRating();
			case 10->{
				mob result=searchbyid();
				if(result!=null) {
					System.out.println("searched"+result);
				}
				else {
					System.out.println("searched_________");
				}
						
			}
			case 11->System.out.println("exit");
			default->System.out.println("invalids");
			}
		}while(choice!=11);
		
	}
	
	public static void addMobi() {
		try {
			System.out.println("enter name:");
			String name=sc.next();
			System.out.println("enter brand:");
			String brand=sc.next();
			System.out.println("enter price:");
			double price=sc.nextDouble();
			System.out.println("enter rating:");
			int rating=sc.nextInt();
			System.out.println("enter range:");
			int range=sc.nextInt();
			System.out.println("enter availabilitys:");
			boolean avai=sc.nextBoolean();
			System.out.println("enter type:");
			brands type=brands.valueOf(sc.next());
			
			mobiless.add(new mob(name,brand,price,rating,range,avai,type));
		}
		catch(ValidationException e) {
			System.out.println("exceptions"+e.getMessage());
		}
	}
	
	static void displayMobi() {
		for(mob x: mobiless) {
			System.out.println(x);
		}
	}
	
	static void sortPrice() {
		mobiless.sort(Comparator.comparingDouble(x->x.price));
		displayMobi();
	}
	
	static void sortId() {
		mobiless.sort(Comparator.comparingInt(x->x.id));
		displayMobi();
	}
	
	static void costliestMobi() {
		mob max=Collections.max(mobiless, Comparator.comparingDouble(x->x.price));
		displayMobi();
	}
	
	static void orderMob() {
		mobiless.sort(Comparator.comparingDouble((mob x)->x.price).reversed());
		displayMobi();
	}
	
	static void updatePrice() {
		System.out.println("enter name");
		String k=sc.next();
		System.out.println("enter price");
		double p=sc.nextDouble();
		
		for(mob x: mobiless) {
			if(x.name.equalsIgnoreCase(k)) {
				x.price=p;
			}
			System.out.println("update price"+k);
		}
	}
	
	static void removeif() {
		mobiless.removeIf(x->!x.avai);
		displayMobi();
	}
	
	static void sortRating() {
		mobiless.sort(Comparator.comparingInt(x->x.rating));
		displayMobi();
	}
	
	static mob searchbyid() {
		System.out.println("enter search");
		int id=sc.nextInt();
		//mob result=searchbyid(id);
		for(mob x:mobiless) {
			if(x.id==id)
				return x;
		}
		return null;
	}
	
	
}
